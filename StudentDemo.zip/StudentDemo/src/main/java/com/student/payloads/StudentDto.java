
package com.student.payloads;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class StudentDto {

	//this variables are shown in the database structure this data will be display in the database
	
	private int id;
	@NotEmpty
	@Size(min=4,message="FirstName must be min of 4 characters !!")
	private String firstname;
	@NotEmpty
	@Size(min=4,message="LastName must be min of 4 characters !!")
	private String lastname;
	@Email(message="email address is not valid")
	private String email;
	@NotEmpty
	@Size(min=1,message="atleast a single number rollno")
	private String rollno;
	@NotEmpty
	@Size(min=6,message="address must be 6 characters")
	private String address;
	@NotEmpty
	@Size(min=4,message="city must be 4 characters")
	private String city;
	@NotEmpty
	@Size(min=4,message="country field must be 6 characters")
	private String country;
	
	
	
}
