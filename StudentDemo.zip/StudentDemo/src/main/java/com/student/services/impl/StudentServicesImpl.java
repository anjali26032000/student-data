package com.student.services.impl;

import java.util.List;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PutMapping;

import com.student.exception.ResourceNotFoundException;
import com.student.entity.Student;
import com.student.payloads.StudentDto;
import com.student.repository.StudentRepo;
import com.student.services3.StudentService;

@Service
public class StudentServicesImpl implements StudentService {
	@Autowired
	private StudentRepo studentRepo;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public StudentDto createStudent(StudentDto studentDto) {
		Student student = this.dtoToStudent(studentDto);
		Student savedStudent = this.studentRepo.save(student);
		return this.studentToDto(savedStudent);
	}

	@Override
	public StudentDto updateStudent(StudentDto studentDto, Integer studentId) {

		Student student=this.studentRepo.findById(studentId).orElseThrow(()->new ResourceNotFoundException("Student", "Id",studentId)); 
		student.setFirstName(studentDto.getFirstname());
		student.setLastName(studentDto.getLastname());
		student.setEmail(studentDto.getEmail());
		student.setAddress(studentDto.getAddress());
		student.setCity(studentDto.getCity());
		student.setRollNo(studentDto.getRollno());
		student.setCountry(studentDto.getCountry());

		Student updatedStudent = this.studentRepo.save(student);
		StudentDto studentDto1 = this.studentToDto(updatedStudent);
		return studentDto1;
	}

	@Override
	public StudentDto getStudentById(Integer studentId) {
		Student student = this.studentRepo.findById(studentId)
				.orElseThrow(()->new ResourceNotFoundException("Student", "Id",studentId));
		return this.studentToDto(student);
	}

	@Override
	public List<StudentDto> getAllStudents() {

		List<Student> students = this.studentRepo.findAll();
		List<StudentDto> studentDtos = students.stream().map(student -> this.studentToDto(student))
				.collect(Collectors.toList());
		return studentDtos;
	}

	@Override
	public void deleteStudent(Integer studentId) {
		Student student = this.studentRepo.findById(studentId)
				.orElseThrow(() -> new ResourceNotFoundException("Student", "Id", studentId));
		this.studentRepo.delete(student);

	}

	public Student dtoToStudent(StudentDto studentDto) {
		Student student = this.modelMapper.map(studentDto, Student.class);
		return student;
	}

	public StudentDto studentToDto(Student student) {
		StudentDto studentDto = this.modelMapper.map(student, StudentDto.class);
		return studentDto;
	}

}
