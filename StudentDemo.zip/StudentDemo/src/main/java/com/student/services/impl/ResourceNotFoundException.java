package com.student.services.impl;

public class ResourceNotFoundException {

}
